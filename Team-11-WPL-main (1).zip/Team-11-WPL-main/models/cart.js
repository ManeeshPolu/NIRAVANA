const mongoose = require('mongoose');
passportLocalMongoose = require('passport-local-mongoose');

const cartItemSchema = new mongoose.Schema({
    itemId: { type: String, required: true },
    count: { type: Number, required: true }
});


const cartSchema = new mongoose.Schema({
    userId: { type: String, required: true},
    items: [cartItemSchema]  
});

cartSchema.plugin(passportLocalMongoose);
const Cart = mongoose.model('Cart', cartSchema);
module.exports = Cart;
